/*
Created By: Daniel Mossie
Double Jump Programming Assignment
Event Listener Class
*/

package com.javaminecraft;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class DoubleJumpEventListener implements Listener{
    
    private final DoubleJump plugin;
    
    public DoubleJumpEventListener (DoubleJump plugin){
        this.plugin = plugin;
    }
    
    //When a block is broken: replace it with the default block
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event){
        event.setCancelled(true);
        String material = plugin.getConfigValue("new_block");
        Material replacement = Material.getMaterial(material);
        if (replacement == null){
            event.getPlayer().sendMessage(ChatColor.RED + "Error: Not a valid material, resetting material to GLASS");
            plugin.configValueChange("new_block","GLASS");
        }
        else{
            event.getBlock().setType(replacement,true);
        }    
    }
}