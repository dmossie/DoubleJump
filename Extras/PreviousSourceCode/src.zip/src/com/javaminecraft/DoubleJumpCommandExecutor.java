/*
Created By: Daniel Mossie
Double Jump Programming Assignment
Command Executor Class
*/

package com.javaminecraft;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class DoubleJumpCommandExecutor implements CommandExecutor{
    
    private final DoubleJump plugin;
    
    public DoubleJumpCommandExecutor (DoubleJump plugin){
        this.plugin = plugin;
    }
    
    //When a command is executed
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args){
        if (cmd.getName().equalsIgnoreCase("doublejump")){
            if (args.length == 0){
                sender.sendMessage("Please specify which command you want to use from the DoubleJump plugin.");
            }
            //Reloads the configuration file
            else if ("reload".equals(args[0])){
                if (sender.hasPermission("DoubleJump.reload")){
                    plugin.reloadConfig();
                    sender.sendMessage(ChatColor.GREEN + "The configuration file was reloaded");
                    return true;
                }
                else{
                    sender.sendMessage(ChatColor.LIGHT_PURPLE + "You do not have permission to use this command");
                }
            }
            //Sets the message when a player joins the server
            else if ("join".equals(args[0])){
                if (sender.hasPermission("DoubleJump.join")){
                    if (args.length == 1){
                        sender.sendMessage(ChatColor.RED + "Please specify a message");
                        return true;
                    }
                    StringBuilder str = new StringBuilder();
                    for (int i = 1; i < args.length; i++) {
                        str.append(args[i]).append(" ");
                    }
                    String message = str.toString();
                    plugin.configValueChange("message", message);
                    sender.sendMessage(ChatColor.GREEN + "Message set to: " + message);
                    return true;
                }
                else{
                    sender.sendMessage(ChatColor.LIGHT_PURPLE + "You do not have permission to use this command");
                }
            }
            //Sets the message when a player joins the server for the first time ever
            else if ("firstjoin".equals(args[0])){
                if (sender.hasPermission("DoubleJump.firstjoin")){
                    if (args.length == 1){
                        sender.sendMessage(ChatColor.RED + "Please specify a message");
                        return false;
                    }
                    StringBuilder str = new StringBuilder();
                    for (int i = 1; i < args.length; i++) {
                        str.append(args[i]).append(" ");
                    }
                    String message = str.toString();
                    plugin.configValueChange("message_first", message);
                    sender.sendMessage(ChatColor.GREEN + "message_first set to: " + message);
                    return true;
                }
                else{
                    sender.sendMessage(ChatColor.LIGHT_PURPLE + "You do not have permission to use this command");
                }
            }
            //Sets the block which broken blocks are changed to
            else if ("block".equals(args[0])){
                if (sender.hasPermission("DoubleJump.block")){
                    if (args.length == 1){
                        sender.sendMessage(ChatColor.RED + "Please specify the block which broken blocks will be turned into");
                        return false;
                    }
                    String block = args[1];
                    if (Material.getMaterial(block.toUpperCase()) == null){
                        sender.sendMessage(ChatColor.RED + "That is not a valid block");
                        return false;
                    }
                    else{
                        plugin.configValueChange("new_block", block.toUpperCase());
                        sender.sendMessage(ChatColor.GREEN + "Replacement block set to: " + block);
                        return true;
                    }
                }
                else{
                    sender.sendMessage(ChatColor.LIGHT_PURPLE + "You do not have permission to use this command");
                }
            }
            else{
                sender.sendMessage(ChatColor.RED + "That is not a valid command.");
            }
        }
        return false;
    }
}